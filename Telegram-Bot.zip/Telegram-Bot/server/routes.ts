import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { startBot, sendMessage, getBotStatus } from "./bot";
import { seedDatabase } from "./seed";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Seed DB
  seedDatabase().catch(err => console.error("Seeding failed:", err));

  // Start the bot
  startBot();

  // API Routes
  app.get(api.messages.list.path, async (req, res) => {
    const messages = await storage.getMessages();
    res.json(messages);
  });

  app.post(api.messages.send.path, async (req, res) => {
    try {
      const { chatId, content } = api.messages.send.input.parse(req.body);
      const result = await sendMessage(chatId, content);
      res.json(result);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input" });
      } else {
        res.status(500).json({ message: err.message || "Failed to send message" });
      }
    }
  });

  app.get(api.status.get.path, async (req, res) => {
    res.json(getBotStatus());
  });

  return httpServer;
}
