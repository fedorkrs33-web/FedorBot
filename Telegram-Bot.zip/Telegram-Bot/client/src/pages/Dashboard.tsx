import { useMessages, useBotStatus } from "@/hooks/use-messages";
import { cn } from "@/lib/utils";
import { Users, MessageCircle, Activity, ArrowUpRight } from "lucide-react";
import { format } from "date-fns";

export default function Dashboard() {
  const { data: messages, isLoading } = useMessages();
  const { data: status } = useBotStatus();

  const totalMessages = messages?.length || 0;
  const uniqueUsers = new Set(messages?.map(m => m.chatId)).size || 0;
  const recentMessages = messages?.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5) || [];

  const stats = [
    { 
      label: "Total Messages", 
      value: totalMessages, 
      icon: MessageCircle, 
      color: "text-blue-500",
      bg: "bg-blue-500/10" 
    },
    { 
      label: "Active Users", 
      value: uniqueUsers, 
      icon: Users, 
      color: "text-emerald-500",
      bg: "bg-emerald-500/10" 
    },
    { 
      label: "Bot Status", 
      value: status?.connected ? "Online" : "Offline", 
      icon: Activity, 
      color: status?.connected ? "text-green-500" : "text-red-500",
      bg: status?.connected ? "bg-green-500/10" : "bg-red-500/10"
    },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-2">Overview of your bot's activity and performance.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-3">
        {stats.map((stat, i) => (
          <div
            key={stat.label}
            className="p-6 rounded-2xl bg-card border border-border/50 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                <h3 className="text-2xl font-bold mt-2">{isLoading ? "..." : stat.value}</h3>
              </div>
              <div className={cn("p-3 rounded-xl", stat.bg)}>
                <stat.icon className={cn("h-6 w-6", stat.color)} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div 
        className="rounded-2xl border border-border/50 bg-card shadow-sm overflow-hidden"
      >
        <div className="p-6 border-b border-border/50 flex items-center justify-between">
          <h2 className="font-semibold text-lg">Recent Activity</h2>
          <button className="text-xs font-medium text-primary hover:text-primary/80 flex items-center gap-1">
            View All <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
        
        <div className="divide-y divide-border/50">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Loading activity...</div>
          ) : recentMessages.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">No messages yet</div>
          ) : (
            recentMessages.map((msg) => (
              <div key={msg.id} className="p-4 flex items-center gap-4 hover:bg-muted/30 transition-colors">
                <div className={cn(
                  "h-10 w-10 rounded-full flex items-center justify-center shrink-0 text-xs font-bold",
                  msg.fromBot 
                    ? "bg-primary/10 text-primary border border-primary/20" 
                    : "bg-orange-500/10 text-orange-600 border border-orange-500/20"
                )}>
                  {msg.fromBot ? "BOT" : (msg.firstName?.[0] || "U")}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium truncate">
                      {msg.fromBot ? "To: " : "From: "} 
                      <span className="text-foreground">
                        {msg.firstName || msg.username || msg.chatId}
                      </span>
                    </p>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {format(new Date(msg.createdAt), "MMM d, h:mm a")}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{msg.content}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
