import { z } from "zod";
import { insertMessageSchema, messages } from "./schema";

export const api = {
  messages: {
    list: {
      method: "GET" as const,
      path: "/api/messages" as const,
      responses: {
        200: z.array(z.custom<typeof messages.$inferSelect>()),
      },
    },
    send: {
      method: "POST" as const,
      path: "/api/messages" as const,
      input: z.object({
        chatId: z.string(),
        content: z.string(),
      }),
      responses: {
        200: z.object({ success: z.boolean(), messageId: z.number().optional() }),
        400: z.object({ message: z.string() }),
        500: z.object({ message: z.string() }),
      },
    },
  },
  status: {
    get: {
      method: "GET" as const,
      path: "/api/status" as const,
      responses: {
        200: z.object({
          connected: z.boolean(),
          username: z.string().optional(),
        }),
      },
    },
  },
};
