## Packages
framer-motion | Smooth animations for messages and layout transitions
date-fns | Formatting timestamps in chat interface

## Notes
- Bot integration assumes backend handles Telegram API calls
- Polling implementation needed for real-time-like message updates (since no WebSocket specified in prompt)
- Color palette: Professional messenger teal/blue aesthetics
