import TelegramBot from "node-telegram-bot-api";
import { storage } from "./storage";

let bot: TelegramBot | null = null;

export function startBot() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.warn("TELEGRAM_BOT_TOKEN is not set. Bot will not start.");
    return;
  }

  if (bot) return; // Already started

  try {
    bot = new TelegramBot(token, { polling: true });

    bot.on("message", async (msg) => {
      const chatId = msg.chat.id.toString();
      const text = msg.text || "(No text content)";
      const username = msg.from?.username;
      const firstName = msg.from?.first_name;
      const messageId = msg.message_id;

      try {
        await storage.createMessage({
          chatId,
          content: text,
          messageId,
          username,
          firstName,
          fromBot: false,
          sender: "user",
        });
        console.log(`Received message from ${chatId}: ${text}`);
      } catch (err) {
        console.error("Failed to save incoming message:", err);
      }
    });

    bot.on("polling_error", (error) => {
      console.error("Telegram Polling Error:", error.message);
    });

    console.log("Telegram Bot started!");
  } catch (err) {
    console.error("Failed to start Telegram Bot:", err);
  }
}

export async function sendMessage(chatId: string, content: string): Promise<{ success: boolean; messageId?: number }> {
  if (!bot) {
    throw new Error("Bot is not connected. Check TELEGRAM_BOT_TOKEN.");
  }

  try {
    const sent = await bot.sendMessage(chatId, content);
    
    // Save outbound message to DB
    await storage.createMessage({
      chatId,
      content,
      messageId: sent.message_id,
      fromBot: true,
      sender: "bot",
      username: bot.options.username, // Might be undefined depending on how it's set
    });

    return { success: true, messageId: sent.message_id };
  } catch (err) {
    console.error("Error sending message:", err);
    throw err;
  }
}

export function getBotStatus() {
  return {
    connected: !!bot,
    username: "Bot", // Could fetch me() info but keeping it simple
  };
}
