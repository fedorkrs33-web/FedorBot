import { useState, useEffect, useRef } from "react";
import { useMessages, useSendMessage } from "@/hooks/use-messages";
import { cn } from "@/lib/utils";
import { ChatMessage } from "@/components/ChatMessage";
import { Send, Search, Loader2, AlertCircle, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Chat() {
  const { data: messages, isLoading, error } = useMessages();
  const { mutate: sendMessage, isPending: isSending } = useSendMessage();
  const { toast } = useToast();
  
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [inputText, setInputText] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Group messages by Chat ID
  const chats = messages?.reduce((acc, msg) => {
    if (!acc[msg.chatId]) {
      acc[msg.chatId] = {
        chatId: msg.chatId,
        username: msg.username,
        firstName: msg.firstName,
        lastMessage: msg,
        messages: []
      };
    }
    acc[msg.chatId].messages.push(msg);
    // Update last message if this one is newer
    if (new Date(msg.createdAt) > new Date(acc[msg.chatId].lastMessage.createdAt)) {
      acc[msg.chatId].lastMessage = msg;
    }
    return acc;
  }, {} as Record<string, any>) || {};

  // Sort chats by latest message
  const sortedChats = Object.values(chats).sort((a: any, b: any) => 
    new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime()
  );

  // Filter chats by search
  const filteredChats = sortedChats.filter((chat: any) => 
    chat.chatId.includes(searchTerm) || 
    chat.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    chat.username?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Get active chat messages sorted by time
  const activeChatMessages = selectedChatId 
    ? chats[selectedChatId]?.messages.sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()) 
    : [];

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [activeChatMessages]);

  // Handle Send
  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedChatId || !inputText.trim()) return;

    sendMessage({
      chatId: selectedChatId,
      content: inputText
    }, {
      onSuccess: () => {
        setInputText("");
      },
      onError: (err) => {
        toast({
          title: "Error sending message",
          description: err.message,
          variant: "destructive"
        });
      }
    });
  };

  if (error) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center p-8">
        <div className="bg-destructive/10 p-4 rounded-full mb-4">
          <AlertCircle className="h-8 w-8 text-destructive" />
        </div>
        <h3 className="text-lg font-semibold text-destructive">Failed to load chats</h3>
        <p className="text-muted-foreground mt-2">Could not connect to the message server.</p>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-2rem)] flex rounded-2xl border border-border/60 bg-card overflow-hidden shadow-sm">
      
      {/* Sidebar: Chat List */}
      <div className="w-80 border-r border-border/60 flex flex-col bg-muted/10">
        <div className="p-4 border-b border-border/60">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input 
              className="w-full bg-background border border-border rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
              placeholder="Search chats..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {isLoading ? (
             <div className="flex flex-col gap-2 p-2">
               {[1, 2, 3].map(i => (
                 <div key={i} className="h-16 bg-muted/40 animate-pulse rounded-xl" />
               ))}
             </div>
          ) : filteredChats.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">
              No chats found
            </div>
          ) : (
            filteredChats.map((chat: any) => (
              <button
                key={chat.chatId}
                onClick={() => setSelectedChatId(chat.chatId)}
                className={cn(
                  "w-full p-3 rounded-xl flex items-start gap-3 text-left transition-all",
                  selectedChatId === chat.chatId 
                    ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" 
                    : "hover:bg-muted/50 text-foreground"
                )}
              >
                <div className={cn(
                  "h-10 w-10 rounded-full flex items-center justify-center shrink-0 font-bold text-sm",
                  selectedChatId === chat.chatId 
                    ? "bg-white/20 text-white" 
                    : "bg-gradient-to-br from-indigo-100 to-purple-100 text-indigo-600 dark:from-indigo-900 dark:to-purple-900 dark:text-indigo-200"
                )}>
                  {chat.firstName?.[0] || "U"}
                </div>
                <div className="flex-1 min-w-0 overflow-hidden">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="font-medium truncate text-sm">
                      {chat.firstName || chat.username || chat.chatId}
                    </span>
                    <span className={cn(
                      "text-[10px] opacity-70 whitespace-nowrap ml-2",
                      selectedChatId === chat.chatId ? "text-primary-foreground" : "text-muted-foreground"
                    )}>
                      {new Date(chat.lastMessage.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </span>
                  </div>
                  <p className={cn(
                    "text-xs truncate",
                    selectedChatId === chat.chatId ? "text-primary-foreground/80" : "text-muted-foreground"
                  )}>
                    {chat.lastMessage.fromBot && "You: "}
                    {chat.lastMessage.content}
                  </p>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Main Area: Conversation */}
      <div className="flex-1 flex flex-col bg-background/50 backdrop-blur-sm relative">
        {selectedChatId ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-border/60 flex items-center gap-3 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md sticky top-0 z-10">
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-100 to-cyan-100 dark:from-blue-900 dark:to-cyan-900 flex items-center justify-center text-blue-700 dark:text-blue-200 font-bold">
                {chats[selectedChatId]?.firstName?.[0] || "U"}
              </div>
              <div>
                <h2 className="font-bold text-sm">
                  {chats[selectedChatId]?.firstName || "Unknown User"}
                </h2>
                <p className="text-xs text-muted-foreground font-mono">
                  ID: {selectedChatId} 
                  {chats[selectedChatId]?.username && ` • @${chats[selectedChatId].username}`}
                </p>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50/50 dark:bg-slate-950/50">
              <div className="max-w-3xl mx-auto">
                {activeChatMessages.map((msg: any) => (
                  <ChatMessage 
                    key={msg.id}
                    content={msg.content}
                    isOutbound={msg.fromBot}
                    timestamp={msg.createdAt}
                    senderName={msg.fromBot ? "Bot" : msg.firstName}
                    username={msg.fromBot ? null : msg.username}
                  />
                ))}
                <div ref={messagesEndRef} />
              </div>
            </div>

            {/* Input Area */}
            <div className="p-4 bg-background border-t border-border/60">
              <form onSubmit={handleSend} className="max-w-3xl mx-auto relative flex items-center gap-3">
                <input
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 bg-muted/30 border border-border/60 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary focus:bg-background transition-all"
                  disabled={isSending}
                />
                <button
                  type="submit"
                  disabled={!inputText.trim() || isSending}
                  className="h-11 w-11 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/25 hover:shadow-xl hover:translate-y-[-2px] hover:shadow-primary/30 active:translate-y-0 active:shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  {isSending ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <Send className="h-5 w-5" />
                  )}
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground p-8">
            <div className="w-24 h-24 bg-muted/20 rounded-full flex items-center justify-center mb-6">
              <MessageCircle className="h-10 w-10 opacity-20" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Select a conversation</h3>
            <p className="text-sm max-w-xs text-center">
              Choose a chat from the sidebar to view history and send messages.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
