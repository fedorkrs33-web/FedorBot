import { Bot, Shield, Globe, Bell } from "lucide-react";
import { useBotStatus } from "@/hooks/use-messages";
import { cn } from "@/lib/utils";

export default function Settings() {
  const { data: status } = useBotStatus();

  const sections = [
    {
      title: "Bot Configuration",
      icon: Bot,
      items: [
        { label: "Bot Name", value: status?.username ? `@${status.username}` : "Loading..." },
        { label: "Status", value: status?.connected ? "Online" : "Offline", active: status?.connected },
        { label: "Environment", value: "Production" }
      ]
    },
    {
      title: "Security",
      icon: Shield,
      items: [
        { label: "Admin Access", value: "Enabled" },
        { label: "2FA", value: "Disabled" }
      ]
    }
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground mt-2">Manage your bot configuration and preferences.</p>
      </div>

      {sections.map((section) => (
        <div key={section.title} className="bg-card rounded-2xl border border-border/50 overflow-hidden shadow-sm">
          <div className="p-4 border-b border-border/50 bg-muted/10 flex items-center gap-2">
            <section.icon className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">{section.title}</h3>
          </div>
          <div className="divide-y divide-border/50">
            {section.items.map((item) => (
              <div key={item.label} className="p-4 flex items-center justify-between hover:bg-muted/20 transition-colors">
                <span className="text-sm font-medium">{item.label}</span>
                <div className="flex items-center gap-2">
                  {item.active !== undefined && (
                    <div className={cn("h-2 w-2 rounded-full", item.active ? "bg-green-500" : "bg-red-500")} />
                  )}
                  <span className="text-sm text-muted-foreground">{item.value}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-2xl p-6 border border-blue-100 dark:border-blue-900/50">
        <div className="flex items-start gap-4">
          <div className="p-2 bg-blue-100 dark:bg-blue-800 rounded-lg">
            <Globe className="h-6 w-6 text-blue-600 dark:text-blue-200" />
          </div>
          <div>
            <h3 className="font-semibold text-blue-900 dark:text-blue-100">Webhook Status</h3>
            <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
              Your bot is currently using long polling. To switch to webhooks, update your configuration in the server environment variables.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
