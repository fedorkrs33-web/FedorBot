import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { User, Bot } from "lucide-react";

interface ChatMessageProps {
  content: string;
  isOutbound: boolean;
  timestamp: string | Date;
  senderName?: string | null;
  username?: string | null;
}

export function ChatMessage({ content, isOutbound, timestamp, senderName, username }: ChatMessageProps) {
  return (
    <div 
      className={cn(
        "flex w-full gap-3 mb-4",
        isOutbound ? "justify-end" : "justify-start"
      )}
    >
      {!isOutbound && (
        <div className="flex-shrink-0 h-8 w-8 rounded-full bg-secondary flex items-center justify-center border border-border">
          <User className="h-4 w-4 text-muted-foreground" />
        </div>
      )}

      <div className={cn(
        "flex flex-col max-w-[70%] sm:max-w-[60%]",
        isOutbound ? "items-end" : "items-start"
      )}>
        {!isOutbound && senderName && (
          <span className="text-xs text-muted-foreground ml-3 mb-1 font-medium">
            {senderName} {username && <span className="opacity-70">(@{username})</span>}
          </span>
        )}

        <div className={cn(
          "px-4 py-2.5 text-sm leading-relaxed break-words relative group transition-shadow rounded-2xl",
          isOutbound 
            ? "bg-primary text-primary-foreground rounded-br-sm" 
            : "bg-card border border-border/60 rounded-bl-sm"
        )}>
          {content}
          
          <div className={cn(
            "text-[10px] mt-1 flex justify-end opacity-70 font-medium",
            isOutbound ? "text-primary-foreground/90" : "text-muted-foreground"
          )}>
            {format(new Date(timestamp), 'HH:mm')}
          </div>
        </div>
      </div>

      {isOutbound && (
        <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
          <Bot className="h-4 w-4 text-primary" />
        </div>
      )}
    </div>
  );
}
