import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type Message } from "@shared/schema";
import { z } from "zod";

// ============================================
// Types
// ============================================

export type SendMessageInput = z.infer<typeof api.messages.send.input>;
export type BotStatus = z.infer<typeof api.status.get.responses[200]>;

// ============================================
// Hooks
// ============================================

// GET /api/messages
// Polls every 2 seconds to simulate real-time
export function useMessages() {
  return useQuery({
    queryKey: [api.messages.list.path],
    queryFn: async () => {
      const res = await fetch(api.messages.list.path);
      if (!res.ok) throw new Error("Failed to fetch messages");
      return api.messages.list.responses[200].parse(await res.json());
    },
    refetchInterval: 2000, // Poll every 2s
  });
}

// POST /api/messages
export function useSendMessage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: SendMessageInput) => {
      const res = await fetch(api.messages.send.path, {
        method: api.messages.send.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to send message");
      }
      
      return api.messages.send.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      // Invalidate messages list to show the new message
      queryClient.invalidateQueries({ queryKey: [api.messages.list.path] });
    },
  });
}

// GET /api/status
export function useBotStatus() {
  return useQuery({
    queryKey: [api.status.get.path],
    queryFn: async () => {
      const res = await fetch(api.status.get.path);
      if (!res.ok) throw new Error("Failed to fetch bot status");
      return api.status.get.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Check connection status every 5s
  });
}
