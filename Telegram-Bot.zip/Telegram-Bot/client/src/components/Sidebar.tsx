import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  MessageSquare, 
  Settings, 
  LayoutDashboard, 
  Bot,
  Wifi,
  WifiOff
} from "lucide-react";
import { useBotStatus } from "@/hooks/use-messages";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const { data: status, isLoading } = useBotStatus();

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/chat", label: "Live Chat", icon: MessageSquare },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className={cn("flex flex-col h-full bg-card border-r border-border", className)}>
      {/* Header */}
      <div className="p-6 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-lg shadow-primary/20">
            <Bot className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight tracking-tight">TeleBot</h1>
            <p className="text-xs text-muted-foreground font-medium">Admin Panel</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer group",
                  isActive 
                    ? "bg-primary/10 text-primary font-semibold shadow-sm" 
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <item.icon className={cn(
                  "h-5 w-5 transition-transform duration-200",
                  isActive ? "scale-110" : "group-hover:scale-110"
                )} />
                <span>{item.label}</span>
                
                {isActive && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Status Footer */}
      <div className="p-4 m-4 rounded-xl bg-muted/50 border border-border/50">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Bot Status</span>
          {isLoading ? (
            <div className="h-2 w-2 rounded-full bg-muted-foreground animate-pulse" />
          ) : status?.connected ? (
            <Wifi className="h-4 w-4 text-green-500" />
          ) : (
            <WifiOff className="h-4 w-4 text-destructive" />
          )}
        </div>
        
        {isLoading ? (
          <div className="h-4 w-24 bg-muted-foreground/10 rounded animate-pulse" />
        ) : (
          <div className="flex items-center gap-2">
            <div className={cn(
              "h-2 w-2 rounded-full animate-pulse",
              status?.connected ? "bg-green-500" : "bg-destructive"
            )} />
            <span className={cn(
              "text-sm font-medium",
              status?.connected ? "text-green-600 dark:text-green-400" : "text-destructive"
            )}>
              {status?.connected ? "Online" : "Disconnected"}
            </span>
          </div>
        )}
        
        {status?.username && (
          <p className="text-xs text-muted-foreground mt-1 truncate">@{status.username}</p>
        )}
      </div>
    </div>
  );
}
