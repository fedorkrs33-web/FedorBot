import { storage } from "./storage";

export async function seedDatabase() {
  const existingMessages = await storage.getMessages();
  if (existingMessages.length > 0) return;

  console.log("Seeding database with sample messages...");

  const sampleMessages = [
    {
      chatId: "123456789",
      content: "Hello! Is this bot working?",
      username: "alice_wonder",
      firstName: "Alice",
      fromBot: false,
      messageId: 1001,
    },
    {
      chatId: "123456789",
      content: "Yes, I am online and ready to help!",
      fromBot: true,
      messageId: 1002,
    },
    {
      chatId: "987654321",
      content: "How do I check my order status?",
      username: "bob_builder",
      firstName: "Bob",
      fromBot: false,
      messageId: 2001,
    },
    {
      chatId: "123456789",
      content: "Great, thanks!",
      username: "alice_wonder",
      firstName: "Alice",
      fromBot: false,
      messageId: 1003,
    },
  ];

  for (const msg of sampleMessages) {
    await storage.createMessage(msg);
  }

  console.log("Seeding complete!");
}
